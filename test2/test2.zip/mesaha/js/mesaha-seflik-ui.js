/* module: mesaha-seflik-governance.js */
/* Mesaha İO V5.82 — Misafir modu Şeflik Yönetimi kilitlenme düzeltmesi */
(function(){
  'use strict';
  if(window.MESAHA_SUITE_MODE){
    window.MesahaSeflikGovernanceApi={suiteManaged:true,loadFolders:async function(){return[]},loadMembers:async function(){return[]},refreshVisible:async function(){return true},refreshAll:async function(){return true},renderTopProfile:function(){},lockTopProfile:function(){},unlockFileSeflikFields:function(){}};return;
  }
  if(window.MesahaSeflikGovernance)return; window.MesahaSeflikGovernance=true;
  var ACTIVE_KEY='mesaha_active_seflik_folder_v564', PANEL_KEY='mesaha_panel_user_v316', SESSION_KEY='mesaha_supabase_v500_session', ACCESS_KEY='mesaha_google_access_v548', SETTINGS_KEY='cam_mesaha_ayarlar_v1', PROFILE_CACHE_KEY='mesaha_google_profile_cache_v568';
  var TERMINAL_KEY='mesaha_terminal_local_mode_v556', TERMINAL_OLD='mesaha_terminal_local_mode_v557';
  var folders=[], members=[], busy=false, searchTimer=0, lastSearch='', memberLoadFor='', lastTopProfileKey='', folderLoadPromise=null, memberLoadPromise=null, memberLoadPromiseFor='', folderLoadedAt=0, memberLoadedAt={};
  function $(id){return document.getElementById(id)}
  function clean(v){return String(v==null?'':v).trim().replace(/\s+/g,' ')}
  function esc(v){return clean(v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
  function getJson(k,f){try{var v=localStorage.getItem(k);return v?JSON.parse(v):f}catch(e){return f}}
  function setJson(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function session(){return getJson(SESSION_KEY,{})||{}}
  function access(){return getJson(ACCESS_KEY,{})||{}}
  function panel(){return getJson(PANEL_KEY,{})||{}}
  function settings(){return getJson(SETTINGS_KEY,{})||{}}
  function terminal(){var x=getJson(TERMINAL_KEY,null)||getJson(TERMINAL_OLD,null)||{};return x&&x.active?x:{}}
  function active(){return getJson(ACTIVE_KEY,{})||{}}
  function profileCache(){return getJson(PROFILE_CACHE_KEY,{})||{}}
  function rememberProfile(n,av){var c=profileCache(),changed=false;n=clean(n);av=clean(av);if(n&&c.name!==n){c.name=n;changed=true}if(/^https?:\/\//i.test(av)&&c.avatarUrl!==av){c.avatarUrl=av;changed=true}if(changed){c.updatedAt=new Date().toISOString();setJson(PROFILE_CACHE_KEY,c)}return c}
  function avatar(){var p=panel(),a=access(),s=session(),u=s.user||{},m=u.user_metadata||{},t=terminal();var vals=[p.googleAvatarUrl,p.avatarUrl,a.avatar_url,a.google_avatar_url,t.avatarUrl,t.avatar_url,m.avatar_url,m.picture];for(var i=0;i<vals.length;i++){var v=clean(vals[i]);if(/^https?:\/\//i.test(v)){rememberProfile('',v);return v}}return clean(profileCache().avatarUrl)}
  function name(){var p=panel(),a=access(),s=session(),u=s.user||{},m=u.user_metadata||{},t=terminal();var n=clean(p.googleFullName||p.name||a.name||a.canonical_name||t.name||m.full_name||m.name||u.email);if(n){rememberProfile(n,'');return n}return clean(profileCache().name)}
  function email(){var a=access(),s=session(),u=s.user||{},p=panel(),t=terminal();return clean(a.email||p.googleEmail||t.pairedEmail||u.email)}
  function api(){return window.mesahaSupabaseV380||window.mesahaSupabaseV383||window.mesahaSupabase||null}
  function terminalAuth(){var t=terminal();if(t.active&&clean(t.source)==='pair_code'&&(t.terminalCode||t.terminalToken))return{terminalCode:clean(t.terminalCode),terminalToken:clean(t.terminalToken),terminalPairedUserId:clean(t.pairedUserId),terminalPairedEmail:clean(t.pairedEmail)};return {}}
  async function edge(action,data){var a=api(); if(!a||typeof a.edge!=='function')throw new Error('Güvenli sunucu bağlantısı hazır değil.'); return await a.edge(action,Object.assign({source:'seflik-governance-v582'},terminalAuth(),data||{}));}
  function toast(t,s,k){try{var f=window.mesahaFloatToastV315||window.mesahaFloatToastV314;if(typeof f==='function')return f(t,s||'',k||'success')}catch(e){} try{if(window.toast)return window.toast(t+(s?' — '+s:''))}catch(e){} alert(t+(s?'\n'+s:''));}
  function googleOk(){var a=access(),s=session(),t=terminal();return !!(s.access_token||a.status==='approved'||(t.active&&t.source==='pair_code'&&(t.pairedUserId||t.terminalToken)))}
  function guestBlockedMessageV582(){var t=terminal();return t.active&&clean(t.source)!=='pair_code'?'Misafir modunda Şeflik Yönetimi buluta bağlanmaz. Terminal kodu eşleştirin veya Google ile giriş yapın.':'Şeflik Yönetimi için Google girişi veya kodla eşleşmiş terminal gerekir.'}
  function googleSessionActive(){var a=access(),s=session();return !!(s.access_token||a.status==='approved')}
  function setActive(f){if(!f||!f.seflik)return;setJson(ACTIVE_KEY,{seflik:f.seflik,seflik_key:f.seflik_key||f.seflikKey,role:f.role||'',creator:!!f.is_creator,created_by_user_id:f.created_by_user_id||'',updatedAt:new Date().toISOString()});try{var p=panel();p.activeSeflik=f.seflik;p.seflik=p.seflik||f.seflik;setJson(PANEL_KEY,p)}catch(e){}try{window.dispatchEvent(new Event('mesaha:seflik-folder-active-changed'))}catch(e){} }
  function activeSeflik(){var a=active(),p=panel(),s=settings(),t=terminal();return clean(a.seflik||p.activeSeflik||p.seflik||t.seflik||s.seflik)}
  function activeSeflikKey(){var a=active();return clean(a.seflik_key||a.seflikKey)}
  function sameSeflik(a,b){return clean(a).toLocaleLowerCase('tr-TR')===clean(b).toLocaleLowerCase('tr-TR')}
  function mergeFallbackFolder(list){list=Array.isArray(list)?list.slice():[];var activeName=activeSeflik(),activeKey=activeSeflikKey();if(activeName&&!list.some(function(f){return sameSeflik(f.seflik,activeName)})){list.unshift({seflik:activeName,seflik_key:activeKey,role:'local',is_local:true,status:'active'});}return list}
  function authoritativeFolderListV68(out){return !!(out&&out.sync_contract==='orman-io-sync-v68'&&out.complete===true&&out.partial!==true&&out.truncated!==true)}
  function mergeFolderListsV68(remote,authoritative){var map=new Map();if(!authoritative)(Array.isArray(folders)?folders:[]).forEach(function(f){var k=clean(f&&f.seflik_key)||clean(f&&f.seflik).toLocaleLowerCase('tr-TR');if(k)map.set(k,f)});(Array.isArray(remote)?remote:[]).forEach(function(f){var k=clean(f&&f.seflik_key)||clean(f&&f.seflik).toLocaleLowerCase('tr-TR');if(k)map.set(k,Object.assign({},map.get(k)||{},f))});return Array.from(map.values())}
  function syncActiveFromFolders(list){list=Array.isArray(list)?list:[];var activeName=activeSeflik(),match=list.find(function(f){return sameSeflik(f.seflik,activeName)});if(match){setActive(match);return match}var preferred=creatorFolder(list)||list[0];if(preferred)setActive(preferred);return preferred||null}
  function viewActive(){var v=$('seflikFolderView');return !!(v&&v.classList.contains('active'))}
  function hash(n){n=clean(n)||'Mesaha';var h=0;for(var i=0;i<n.length;i++)h=((h<<5)-h+n.charCodeAt(i))|0;return Math.abs(h)}
  function palette(n){var h=hash(n)%360;return {p1:'hsl('+h+' 72% 45%)',p2:'hsl('+((h+45)%360)+' 78% 56%)',p3:'hsl('+((h+190)%360)+' 60% 92%)'}}
  function ensureStyles(){if($('mesaha-v570-style'))return;var st=document.createElement('style');st.id='mesaha-v570-style';st.textContent='\
.topbar #userBadge{display:none!important}.topbar .top-actions-v316{margin-left:auto!important;display:flex!important;align-items:center!important}.topbar #userPanelBtnV316{display:inline-flex!important;align-items:center!important;gap:7px!important;min-height:34px!important;max-width:190px!important;padding:5px 9px 5px 6px!important;border-radius:999px!important;background:rgba(255,255,255,.86)!important;border:1px solid rgba(148,163,184,.28)!important;box-shadow:0 10px 24px rgba(15,23,42,.08)!important;color:#0f172a!important;font-weight:950!important;font-size:12px!important;white-space:nowrap!important;overflow:hidden!important}.topbar #userPanelBtnV316 .top-profile-avatar,.mesaha-v565-profile .profile-avatar{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;object-fit:cover;flex:none;background:linear-gradient(135deg,var(--p1,#0d5f3b),var(--p2,#2563eb));color:#fff;font-weight:1000}.topbar #userPanelBtnV316 .top-profile-name{overflow:hidden;text-overflow:ellipsis;max-width:126px}.topbar #userPanelBtnV316 img.top-profile-avatar{border:1.5px solid #fff;box-shadow:0 5px 12px rgba(15,23,42,.16)}.mesaha-v565-profile{position:relative;display:flex;align-items:center;gap:13px;border:1px solid rgba(148,163,184,.22);background:linear-gradient(135deg,var(--p3,#eefaf3),#fff);border-radius:22px;padding:13px;margin:10px 0 12px;overflow:hidden;color:#0f172a}.mesaha-v565-profile:before{content:"";position:absolute;inset:0 auto 0 0;width:6px;background:linear-gradient(180deg,var(--p1,#0d5f3b),var(--p2,#2563eb))}.mesaha-v565-profile img.profile-avatar,.mesaha-v565-profile .profile-avatar{width:58px;height:58px;border-radius:50%;object-fit:cover;border:3px solid #fff;box-shadow:0 10px 24px rgba(15,23,42,.16);font-size:22px}.mesaha-v565-profile .profile-main{min-width:0}.mesaha-v565-profile b{display:block;font-size:18px;font-weight:1000;letter-spacing:-.02em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mesaha-v565-profile .profile-sub{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}.mesaha-v565-profile .mini-pill{display:inline-flex;align-items:center;gap:5px;border-radius:999px;padding:5px 8px;background:#fff;border:1px solid rgba(148,163,184,.25);font-size:11px;font-weight:900;color:#475569}.seflik-v564-box{border:1px solid #bfdbfe;background:linear-gradient(135deg,#eff6ff,#f8fafc);border-radius:22px;padding:14px;margin:0 0 14px;color:#0f172a}.seflik-v564-box h3{margin:0 0 4px;font-size:18px}.seflik-v564-box p{margin:0 0 12px;color:#64748b;font-weight:750;line-height:1.45}.seflik-v564-grid{display:grid;gap:10px}.seflik-v564-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.seflik-v564-row input,.seflik-v564-row select{flex:1;min-width:180px;min-height:46px;border:1px solid #cbd5e1;border-radius:14px;padding:10px 12px;font:inherit;font-weight:850;background:white}.seflik-v564-row button{min-height:46px}.seflik-v564-row button:disabled{opacity:.55;filter:grayscale(.25);cursor:not-allowed}.seflik-v564-members{display:grid;gap:8px;margin-top:8px}.seflik-v564-user{display:flex;align-items:center;gap:10px;border:1px solid #e2e8f0;background:white;border-radius:15px;padding:8px}.seflik-v564-user img{width:38px;height:38px;border-radius:50%;object-fit:cover}.seflik-v564-user .avatar-fallback{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:#e0f2fe;color:#075985;font-weight:1000}.seflik-v564-user b{font-size:13px}.seflik-v564-user small{display:block;color:#64748b;font-weight:750}.seflik-v564-user button{margin-left:auto}.seflik-v564-danger,#seflikDeleteBtnV564,#seflikGovernanceV564 .seflik-v564-danger,#seflikGovernanceV564 [data-remove-member-v566],#seflikMemberListV566 .remove-member{background:linear-gradient(180deg,#ef4444,#b91c1c)!important;color:#fff!important;border-color:#991b1b!important;box-shadow:0 10px 22px rgba(185,28,28,.22)!important;text-shadow:none!important}.seflik-v564-danger:hover,#seflikDeleteBtnV564:hover,#seflikGovernanceV564 [data-remove-member-v566]:hover{filter:brightness(.98)!important}.seflik-v566-member-list .remove-member{background:linear-gradient(180deg,#ef4444,#b91c1c)!important;color:#fff!important;border-color:#991b1b!important}.seflik-v564-note{font-size:12px;color:#64748b;font-weight:800;line-height:1.45}.seflik-v564-note.warn{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;border-radius:14px;padding:9px}.seflik-v564-note.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534;border-radius:14px;padding:9px}.panel-field-v316 small{display:block;font-size:11px;color:#64748b;margin-top:3px}.file-seflik-note-v564{font-size:11px;color:#64748b;font-weight:800;margin-top:3px}.seflik-suggest-hint-v565{font-size:11px;color:#64748b;font-weight:850;margin-top:-4px}.seflik-v566-member-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:10px;padding-top:10px;border-top:1px dashed #cbd5e1}.seflik-v566-member-title b{font-size:14px}.seflik-v566-member-title small{color:#64748b;font-weight:850}.seflik-v566-member-list{display:grid;gap:8px;margin-top:8px}.seflik-v566-member-list .role-owner{background:#ecfdf5;border-color:#bbf7d0}.seflik-v566-member-list .role-member{background:#fff}.seflik-v566-member-list .remove-member{margin-left:auto}\
@media(max-width:480px){.topbar #userPanelBtnV316{max-width:150px}.topbar #userPanelBtnV316 .top-profile-name{max-width:92px}.mesaha-v565-profile b{font-size:16px}.mesaha-v565-profile img.profile-avatar,.mesaha-v565-profile .profile-avatar{width:52px;height:52px}}\
';document.head.appendChild(st)}
  function avatarHtml(url,n,cls){url=clean(url);n=clean(n);var c=cls||'';if(url)return '<img class="'+c+'" src="'+esc(url)+'" alt="" referrerpolicy="no-referrer" loading="lazy" decoding="async">';return '<span class="avatar-fallback '+c+'">'+esc((n||'?').charAt(0).toLocaleUpperCase('tr-TR'))+'</span>'}
  function profileAvatar(url,n,cls){url=clean(url);n=clean(n);var c=cls||'profile-avatar';if(url)return '<img class="'+c+'" src="'+esc(url)+'" alt="" referrerpolicy="no-referrer" loading="eager" decoding="async">';return '<span class="'+c+'">'+esc((n||'?').charAt(0).toLocaleUpperCase('tr-TR'))+'</span>'}
  function sessionLabel(){var t=terminal();if(t.active&&t.source==='pair_code')return 'Terminal kodlu'; if(t.active)return 'Misafir mod'; if(googleSessionActive())return 'Google hesabı'; return 'Yerel kullanım'}
  function renderProfile(){ensureStyles();var card=document.querySelector('#userPanelOverlayV316 .panel-card-v316');if(!card)return;var box=$('mesahaProfileV564')||$('mesahaProfileV565');if(!box){box=document.createElement('div');box.id='mesahaProfileV565';box.className='mesaha-v565-profile';var before=document.querySelector('#userPanelOverlayV316 .panel-grid-v316')||$('panelSessionV563');card.insertBefore(box,before||card.firstChild)}box.id='mesahaProfileV565';box.className='mesaha-v565-profile';var n=name()||'Kullanıcı',av=avatar(),pal=palette(n);rememberProfile(n,av);box.style.setProperty('--p1',pal.p1);box.style.setProperty('--p2',pal.p2);box.style.setProperty('--p3',pal.p3);box.innerHTML=profileAvatar(av,n,'profile-avatar')+'<div class="profile-main"><b>'+esc(n)+'</b><div class="profile-sub"><span class="mini-pill">'+esc(sessionLabel())+'</span>'+(email()?'<span class="mini-pill">'+esc(email())+'</span>':'')+'</div></div>';var p=panel();if(av&&(p.googleAvatarUrl!==av||p.avatarUrl!==av)){p.googleAvatarUrl=av;p.avatarUrl=av;setJson(PANEL_KEY,p)} }
  function unlockFileSeflikFields(){['seflik','panelSeflikV316'].forEach(function(id){var el=$(id);if(!el)return;try{el.readOnly=false;el.disabled=false;el.removeAttribute('readonly');el.removeAttribute('aria-readonly');el.removeAttribute('disabled');el.classList.remove('readonly','locked','google-locked')}catch(e){}})}
  function renderTopProfile(){ensureStyles();var btn=$('userPanelBtnV316');if(!btn)return;var cached=profileCache(),n=name()||clean(cached.name),av=avatar()||clean(btn.dataset.avatarUrlV568||cached.avatarUrl),pal=palette(n||'Giriş');if(n||av)rememberProfile(n,av);if(av)btn.dataset.avatarUrlV568=av;btn.classList.add('mesaha-profile-locked-v568');btn.setAttribute('type','button');btn.style.setProperty('--p1',pal.p1);btn.style.setProperty('--p2',pal.p2);btn.style.setProperty('--p3',pal.p3);var key=(n||'')+'|'+(av||'');window.__mesahaRenderingTopProfileV568=true;try{if(btn.dataset.profileKeyV568!==key||!btn.querySelector('.top-profile-name')){btn.dataset.profileKeyV568=key;if(n){btn.innerHTML=profileAvatar(av,n,'top-profile-avatar')+'<span class="top-profile-name">'+esc(n)+'</span>';btn.title=n}else{btn.innerHTML='<span class="top-profile-avatar">G</span><span class="top-profile-name">Giriş Yap</span>';btn.title='Giriş Yap'}}}finally{setTimeout(function(){window.__mesahaRenderingTopProfileV568=false},0)}var badge=$('userBadge');if(badge){badge.textContent=n||'Giriş Yap';badge.classList.toggle('login-needed',!n)}}
  function lockTopProfile(){var btn=$('userPanelBtnV316');if(!btn||btn.__profileLockV568)return;btn.__profileLockV568=true;var refresh=function(){if(window.__mesahaRenderingTopProfileV568)return;clearTimeout(btn.__profileLockTimerV568);btn.__profileLockTimerV568=setTimeout(renderTopProfile,16)};try{new MutationObserver(refresh).observe(btn,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class','style','title']})}catch(e){}['mesaha:user-login','mesaha:google-access-approved','storage'].forEach(function(ev){window.addEventListener(ev,refresh,{passive:true})})}
  function relabelFields(){unlockFileSeflikFields();var l=$('seflik')&&$('seflik').closest('label');if(l&&!l.__v565){l.__v565=true;var input=$('seflik');try{l.childNodes[0].nodeValue='Dosya Şefliği '}catch(e){}var note=document.createElement('div');note.className='file-seflik-note-v564';note.textContent='Sadece dosya adı ve mesaha bilgisi için kullanılır; istediğiniz zaman değiştirilebilir.';input&&input.parentNode.appendChild(note)}var p=$('panelSeflikV316')&&$('panelSeflikV316').closest('label');if(p&&!p.__v565){p.__v565=true;try{p.childNodes[0].nodeValue='Dosya Şefliği '}catch(e){}var sm=document.createElement('small');sm.textContent='Dosya adı için serbesttir; ortak klasör yetkisini değiştirmez.';p.appendChild(sm)}renderTopProfile();}
  function creatorFolder(list){return (list||[]).find(function(f){return !!f.is_creator&&clean(f.status||'active')==='active'})||null}
  function loadFolders(silent,force){
    if(!googleOk()){folders=mergeFallbackFolder([]);renderFolders(folders, 'Google veya terminal koduyla eşleşince Şeflik Klasörü açılır.');return Promise.resolve(folders)}
    if(!force&&folderLoadPromise)return folderLoadPromise;
    if(!force&&folders.length&&Date.now()-folderLoadedAt<12000){folders=mergeFallbackFolder(folders);syncActiveFromFolders(folders);renderFolders(folders);return Promise.resolve(folders)}
    renderFolders(mergeFallbackFolder(folders), 'Şeflikler yükleniyor…');
    folderLoadPromise=(async function(){
      try{
        var activeName=activeSeflik(),ensured=null;
        if(activeName){try{ensured=await edge('seflik_folder_ensure_active',{seflik:activeName,folderSeflik:activeName,seflikKey:activeSeflikKey()});if(ensured&&ensured.ok&&ensured.folder)setActive(ensured.folder)}catch(_ensureError){}}
        var out=await edge('seflik_folder_list_my_sefliks',{seflik:activeSeflik(),folderSeflik:activeSeflik()});
        var raw=Array.isArray(out.folders)?out.folders:[],authoritative=authoritativeFolderListV68(out);
        if(ensured&&ensured.folder&&!raw.some(function(f){return sameSeflik(f.seflik,ensured.folder.seflik)}))raw.push(ensured.folder);
        folders=mergeFallbackFolder(mergeFolderListsV68(raw,authoritative));folderLoadedAt=Date.now();syncActiveFromFolders(folders);renderFolders(folders,authoritative?'':'Eksik sunucu cevabı: mevcut şeflikler korundu.');return folders
      }
      catch(e){if(!silent)toast('Şeflikler alınamadı',String(e&&e.message?e.message:e),'error');folders=mergeFallbackFolder(folders);syncActiveFromFolders(folders);renderFolders(folders,String(e&&e.message?e.message:e));return folders}
    })().finally(function(){folderLoadPromise=null});
    return folderLoadPromise;
  }
  function activeFolder(){var sf=activeSeflik();return (folders||[]).find(function(f){return sameSeflik(f.seflik,sf)})||{} }
  function activeCreator(){var f=activeFolder();return !!f.is_creator}
  function loadMembers(silent,force){
    var sf=activeSeflik();memberLoadFor=sf;
    if(!sf||!googleOk()){members=[];renderMemberList('');return Promise.resolve([])}
    renderMemberList('Üyeler yükleniyor…');
    if(!force&&memberLoadPromise&&memberLoadPromiseFor===sf)return memberLoadPromise;
    if(!force&&memberLoadedAt[sf]&&Date.now()-memberLoadedAt[sf]<15000){renderMemberList('');return Promise.resolve(members)}
    memberLoadPromiseFor=sf;
    memberLoadPromise=(async function(){
      try{var out=await edge('seflik_folder_list_members',{seflik:sf,folderSeflik:sf});if(memberLoadFor!==sf)return members;members=Array.isArray(out.members)?out.members:[];memberLoadedAt[sf]=Date.now();renderMemberList('',!!out.is_creator);return members}
      catch(e){if(memberLoadFor===sf){members=[];if(!silent)toast('Ormancılar alınamadı',String(e&&e.message?e.message:e),'error');renderMemberList(String(e&&e.message?e.message:e))}return []}
    })().finally(function(){if(memberLoadPromiseFor===sf){memberLoadPromise=null;memberLoadPromiseFor=''}});
    return memberLoadPromise;
  }
  function renderMemberList(msg,creatorFlag){if(/Bilinmeyen.*seflik_folder_list_members/i.test(String(msg||'')))msg='Şeflik üyeleri için sunucu güncellemesi gerekli.';var box=$('seflikMemberListV566');if(!box)return;var sf=activeSeflik();if(!sf){box.innerHTML='<div class="seflik-v564-note">Ekli ormancılar için önce şeflik seçin.</div>';return}var title='<div class="seflik-v566-member-title"><b>Ekli Ormancılar</b><small>'+esc(sf)+'</small></div>';if(msg){box.innerHTML=title+'<div class="seflik-v564-note">'+esc(msg)+'</div>';return}if(!members.length){box.innerHTML=title+'<div class="seflik-v564-note">Bu şeflikte henüz ekli ormancı yok.</div>';return}box.innerHTML=title+'<div class="seflik-v566-member-list">'+members.map(function(m){var role=clean(m.role)==='owner'?'Kurucu':'Ormancı';return '<div class="seflik-v564-user '+(clean(m.role)==='owner'?'role-owner':'role-member')+'">'+avatarHtml(m.avatar_url,m.name)+'<div><b>'+esc(m.name||'-')+'</b><small>'+esc(role+(m.email?' • '+m.email:''))+'</small></div></div>'}).join('')+'</div>'}
  async function removeMember(uid){var sf=activeSeflik();if(!uid||!sf)return;if(!confirm('Bu ormancı şeflik klasöründen çıkarılsın mı?'))return;try{await edge('seflik_folder_remove_member',{seflik:sf,member_user_id:uid});toast('Ormancı çıkarıldı','Kullanıcı artık bu şeflik klasörünü kullanamaz.','success');await loadMembers(true,true)}catch(e){toast('Ormancı çıkarılamadı',String(e&&e.message?e.message:e),'error')}}
  function renderFolders(list,msg){ensureStyles();var host=document.querySelector('#seflikFolderView .seflik-folder-control');if(!host)return;list=mergeFallbackFolder(list||[]);var box=$('seflikGovernanceV564');if(!box){box=document.createElement('section');box.id='seflikGovernanceV564';box.className='seflik-v564-box';host.parentNode.insertBefore(box,host)}var activeName=activeSeflik();var loadingNote=msg?'<div class="seflik-v564-note '+(/yükleniyor/i.test(String(msg))?'ok':'')+'">'+esc(msg)+'</div>':'';box.innerHTML='<h3>Şeflik Seçimi</h3><p>Şeflik, ormancı ve bölme yönetimi Orman İO ana menüsünden yapılır. Burada yalnızca aktif şefliği seçebilirsiniz.</p><div class="seflik-v564-grid"><div class="seflik-v564-row"><select id="seflikSelectV564"><option value="">Şeflik seçin</option>'+((list||[]).map(function(f){var local=f.is_local?' • yerel':'';return '<option value="'+esc(f.seflik)+'" '+(sameSeflik(f.seflik,activeName)?'selected':'')+'>'+esc(f.seflik)+(f.is_creator?' • kurucu':local||' • üye')+'</option>'}).join(''))+'</select></div>'+loadingNote+'<div class="seflik-v564-note ok">Düzenleme yapmak için Orman İO ana menüsüne dönün.</div></div>';bindBox()}
  function bindBox(){var sel=$('seflikSelectV564');if(sel&&!sel.__b){sel.__b=true;sel.addEventListener('change',function(){var v=clean(sel.value),f=folders.find(function(x){return sameSeflik(x.seflik,v)});if(f){setActive(f);renderFolders(folders);try{if(window.MesahaSeflikFolderV529)window.MesahaSeflikFolderV529.autoSync?window.MesahaSeflikFolderV529.autoSync():window.MesahaSeflikFolderV529.sync(false,{silent:true})}catch(e){}}})}}
  async function createFolder(){if(busy)return;var existing=creatorFolder(folders);if(existing)return toast('Yeni şeflik oluşturulamaz','Bu kullanıcı zaten '+existing.seflik+' şefliğini kurmuş. Silmeden ikinci şeflik kurulamaz.','warning');var inp=$('seflikCreateNameV564'),v=clean(inp&&inp.value);if(v.length<2)return toast('Şeflik adı gerekli','Oluşturulacak şefliği yazın.','warning');busy=true;try{var out=await edge('seflik_folder_create_seflik',{seflik:v});var f=out.folder||{seflik:v,seflik_key:out.seflik_key,is_creator:true};setActive(f);if(inp)inp.value='';toast(out.duplicate?'Şeflik zaten var':'Şeflik oluşturuldu',v,'success');await loadFolders(true,true);await loadMembers(true,true);try{if(window.MesahaSeflikFolderV529)window.MesahaSeflikFolderV529.autoSync?window.MesahaSeflikFolderV529.autoSync():window.MesahaSeflikFolderV529.sync(false)}catch(e){}}catch(e){toast('Şeflik oluşturulamadı',String(e&&e.message?e.message:e),'error')}finally{busy=false}}
  async function deleteFolder(){var v=activeSeflik();if(!v)return; if(!confirm(v+' şefliği ve içindeki ortak klasör kayıtları silinsin mi? Sadece kurucu silebilir.'))return;busy=true;try{await edge('seflik_folder_delete_seflik',{seflik:v,confirmSeflik:v});try{localStorage.removeItem(ACTIVE_KEY)}catch(e){}toast('Şeflik silindi',v,'success');await loadFolders(true,true);await loadMembers(true,true);try{if(window.MesahaSeflikFolderV529)window.MesahaSeflikFolderV529.autoSync?window.MesahaSeflikFolderV529.autoSync():window.MesahaSeflikFolderV529.sync(false)}catch(e){}}catch(e){toast('Şeflik silinemedi',String(e&&e.message?e.message:e),'error')}finally{busy=false}}
  async function searchUsers(force){var q=clean(($('seflikUserSearchV564')||{}).value),box=$('seflikSearchResultsV564'),sf=activeSeflik();if(!sf)return toast('Önce şeflik seçin','Ormancı eklemek için aktif şeflik gerekli.','warning');if(q.length<3){if(force)toast('En az 3 harf yazın','Öneri için ad soyadın 3 harfi gerekli.','warning');return}if(!force&&q===lastSearch)return;lastSearch=q;if(box)box.innerHTML='<div class="seflik-v564-note">Kullanıcılar aranıyor…</div>';try{var out=await edge('seflik_folder_search_users',{query:q,seflik:sf});var users=Array.isArray(out.users)?out.users:[];users.sort(function(a,b){return clean(a.name||a.email).localeCompare(clean(b.name||b.email),'tr')});if(!users.length){if(box)box.innerHTML='<div class="seflik-v564-note">Kullanıcı bulunamadı. Eklemek istediğiniz kişinin önce Google ile giriş yapması gerekir.</div>';return}if(box)box.innerHTML=users.map(function(u){return '<div class="seflik-v564-user">'+avatarHtml(u.avatar_url,u.name)+'<div><b>'+esc(u.name||'-')+'</b><small>'+esc(u.email||'')+'</small></div><button class="btn soft" data-add-user-v564="'+esc(u.user_id)+'">Ekle</button></div>'}).join('');document.querySelectorAll('[data-add-user-v564]').forEach(function(b){if(!b.__b){b.__b=true;b.onclick=function(){addMember(b.getAttribute('data-add-user-v564'))}}})}catch(e){if(box)box.innerHTML='<div class="seflik-v564-note">'+esc(String(e&&e.message?e.message:e))+'</div>'}}
  async function addMember(uid){var sf=activeSeflik();if(!uid||!sf)return;try{await edge('seflik_folder_add_member',{seflik:sf,member_user_id:uid});toast('Ormancı eklendi','Kullanıcı artık bu şeflik klasörünü kullanabilir.','success');await loadFolders(true,true);await loadMembers(true,true)}catch(e){toast('Ormancı eklenemedi',String(e&&e.message?e.message:e),'error')}}
  function setFolderBusyText(text){var meta=$('seflikFolderRemoteMetaV528');if(meta)meta.textContent=text;var st=$('seflikFolderStatusV528');if(st)st.textContent=text;try{var r=window.MesahaSeflikEntryRepairV581||window.MesahaSeflikEntryRepairV582;if(r&&/yükleniyor|getiriliyor/i.test(String(text)))r.showLoading('Şeflik klasörü getiriliyor…',String(text),12);if(r&&/Bağlantı|başarısız|cevap/i.test(String(text))){r.updateLoading('Bağlantı başarısız','En son mevcut bilgiler gösteriliyor.',100);r.hideLoading(1200)}if(r&&/Misafir|Google|terminal kod|kapalı|güncellendi|gerekir/i.test(String(text))){r.updateLoading('Şeflik Klasörü',String(text),100);r.hideLoading(650)}}catch(e){}}
  function withTimeout(promise,ms){var timer=0;return Promise.race([Promise.resolve(promise),new Promise(function(_,reject){timer=setTimeout(function(){reject(new Error('10 saniyede cevap gelmedi. Bağlantı yok, daha sonra tekrar deneyiniz.'))},ms)})]).finally(function(){if(timer)clearTimeout(timer)});}
  async function refreshAll(force){if(!viewActive()&&!force)return;if(!googleOk()){var msg=guestBlockedMessageV582();renderFolders(mergeFallbackFolder(folders),msg);renderMemberList(msg);setFolderBusyText(msg);return}setFolderBusyText('Şeflik klasörü getiriliyor…');try{await withTimeout(loadFolders(true,!!force),10000);await withTimeout(Promise.allSettled([loadMembers(true,!!force),window.MesahaSeflikFolderV529&&window.MesahaSeflikFolderV529.autoSync?window.MesahaSeflikFolderV529.autoSync():Promise.resolve()]),10000);setFolderBusyText('Şeflik klasörü güncellendi.')}catch(e){setFolderBusyText('Bağlantı yok veya sunucu 10 saniye içinde cevap vermedi. Daha sonra tekrar deneyiniz.');if(force)toast('Şeflik yüklenemedi',String(e&&e.message?e.message:e),'warning')}}
  function boot(){ensureStyles();relabelFields();renderProfile();renderTopProfile();lockTopProfile();unlockFileSeflikFields();if(document.getElementById('seflikFolderView')){renderFolders(folders);if(viewActive())loadFolders(true,false)}}
  function refreshVisibleFolder(force){refreshAll(!!force).catch(function(){})}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
  [180,1100].forEach(function(ms){setTimeout(boot,ms)});
  document.addEventListener('click',function(ev){var n=ev.target&&ev.target.closest&&ev.target.closest('[data-nav="seflikFolder"]');if(n){if(!googleOk()){ev.preventDefault();ev.stopPropagation();ev.stopImmediatePropagation();var msg=guestBlockedMessageV582();renderFolders(mergeFallbackFolder(folders),msg);renderMemberList(msg);setFolderBusyText(msg);toast('Şeflik Klasörü kapalı',msg,'warning');return false}setFolderBusyText('Şeflik yükleniyor…');setTimeout(function(){refreshVisibleFolder(true)},40)}},true);
  window.addEventListener('pageshow',function(){setTimeout(boot,80)});window.addEventListener('mesaha:google-access-approved',function(){folderLoadedAt=0;setTimeout(function(){boot();refreshVisibleFolder(true)},100)});window.addEventListener('mesaha:user-login',function(){folderLoadedAt=0;setTimeout(function(){relabelFields();renderProfile();renderTopProfile();refreshVisibleFolder(true)},100)});
  var p=$('userPanelOverlayV316');if(p&&window.MutationObserver&&!p.__v565ProfileWatch){p.__v565ProfileWatch=true;new MutationObserver(function(){setTimeout(function(){renderProfile();relabelFields();renderTopProfile()},60)}).observe(p,{attributes:true,attributeFilter:['class']})}
  window.MesahaSeflikGovernanceApi={loadFolders:loadFolders,loadMembers:loadMembers,refreshVisible:refreshVisibleFolder,refreshAll:refreshAll,renderTopProfile:renderTopProfile,lockTopProfile:lockTopProfile,unlockFileSeflikFields:unlockFileSeflikFields};
})();
;

/* module: mesaha-seflik-entry-repair.js */
/* Mesaha İO V5.82 — Misafir modunda Şeflik Klasörü yüklenme kilidi önleme. */
(function(){
  'use strict';
  if(window.MESAHA_SUITE_MODE){
    var suiteRepairStub={suiteManaged:true,refresh:async function(){return true},showLoading:function(){},updateLoading:function(){},hideLoading:function(){},showLocalMemberFallback:function(){}};
    window.MesahaSeflikEntryRepairV581=suiteRepairStub;window.MesahaSeflikEntryRepairV582=suiteRepairStub;return;
  }
  if(window.__mesahaSeflikEntryRepairV582) return;
  window.__mesahaSeflikEntryRepairV582 = true;

  var ACTIVE_KEY='mesaha_active_seflik_folder_v564';
  var PANEL_KEY='mesaha_panel_user_v316';
  var SETTINGS_KEY='cam_mesaha_ayarlar_v1';
  var ACCESS_KEY='mesaha_google_access_v548';
  var SESSION_KEY='mesaha_supabase_v500_session';
  var TERMINAL_KEY='mesaha_terminal_local_mode_v556';
  var TERMINAL_OLD='mesaha_terminal_local_mode_v557';
  var refreshPromise=null;
  var lastWarnAt=0;
  var lastStartedAt=0;

  function $(id){return document.getElementById(id)}
  function clean(v){return String(v==null?'':v).trim().replace(/\s+/g,' ')}
  function esc(v){return clean(v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
  function getJson(k,f){try{var v=localStorage.getItem(k);return v?JSON.parse(v):f}catch(e){return f}}
  function setJson(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function active(){return getJson(ACTIVE_KEY,{})||{}}
  function panel(){return getJson(PANEL_KEY,{})||{}}
  function settings(){return getJson(SETTINGS_KEY,{})||{}}
  function access(){return getJson(ACCESS_KEY,{})||{}}
  function session(){try{if(window.OrmanSuiteIdentity&&window.OrmanSuiteIdentity.session)return window.OrmanSuiteIdentity.session()||{}}catch(e){}return getJson(SESSION_KEY,{})||{}}
  function terminal(){try{if(window.OrmanSuiteIdentity&&window.OrmanSuiteIdentity.terminal)return window.OrmanSuiteIdentity.terminal()||{}}catch(e){}var x=getJson(TERMINAL_KEY,null)||getJson(TERMINAL_OLD,null)||{};return x&&x.active?x:{}}
  function activeSeflik(){try{if(window.OrmanSuiteIdentity&&window.OrmanSuiteIdentity.identity)return clean(window.OrmanSuiteIdentity.identity().seflik)}catch(e){}var a=active(),p=panel(),s=settings(),t=terminal();return clean(a.seflik||p.activeSeflik||p.seflik||t.seflik||s.seflik)}
  function activeKey(){try{if(window.OrmanSuiteIdentity&&window.OrmanSuiteIdentity.identity)return clean(window.OrmanSuiteIdentity.identity().seflikKey)}catch(e){}var a=active();return clean(a.seflik_key||a.seflikKey)}
  function userName(){var p=panel(),a=access(),s=session(),u=s.user||{},m=u.user_metadata||{},t=terminal();return clean(p.googleFullName||p.name||a.canonical_name||a.requested_name||t.name||m.full_name||m.name||u.email||'Kullanıcı')}
  function userEmail(){var p=panel(),a=access(),s=session(),u=s.user||{},t=terminal();return clean(a.email||p.googleEmail||t.pairedEmail||u.email)}
  function avatar(){var p=panel(),a=access(),s=session(),u=s.user||{},m=u.user_metadata||{},t=terminal();var vals=[p.googleAvatarUrl,p.avatarUrl,a.avatar_url,a.google_avatar_url,t.avatarUrl,t.avatar_url,m.avatar_url,m.picture];for(var i=0;i<vals.length;i++){var v=clean(vals[i]);if(/^https?:\/\//i.test(v))return v}return ''}
  function api(){return window.mesahaSupabaseV380||window.mesahaSupabaseV383||window.mesahaSupabase||null}
  function terminalAuth(){try{if(window.OrmanSuiteIdentity&&window.OrmanSuiteIdentity.terminalAuthPayload)return window.OrmanSuiteIdentity.terminalAuthPayload()||{}}catch(e){}var t=terminal();if(t.active&&clean(t.source)==='pair_code'&&(t.terminalCode||t.terminalToken))return{terminalCode:clean(t.terminalCode),terminalToken:clean(t.terminalToken),terminalPairedUserId:clean(t.pairedUserId),terminalPairedEmail:clean(t.pairedEmail)};return {}}
  function pairedTerminal(){try{if(window.OrmanSuiteIdentity&&window.OrmanSuiteIdentity.pairedTerminal)return window.OrmanSuiteIdentity.pairedTerminal()}catch(e){}var t=terminal();return !!(t.active&&clean(t.source)==='pair_code'&&(t.pairedUserId||t.terminalToken||t.terminalCode))}
  function cloudAccess(){try{if(window.OrmanSuiteIdentity&&window.OrmanSuiteIdentity.cloudAllowed)return window.OrmanSuiteIdentity.cloudAllowed()}catch(e){}return !!(session().access_token||pairedTerminal())}
  function blockedMessage(){var t=terminal();return t.active&&!pairedTerminal()?'Misafir modunda Şeflik Klasörü buluta bağlanmaz. Terminal kodu eşleştirin veya Google ile giriş yapın.':'Şeflik Klasörü için Google girişi veya kodla eşleşmiş terminal gerekir.'}
  function edge(action,data){var a=api();if(!a||typeof a.edge!=='function')return Promise.reject(new Error('Güvenli sunucu bağlantısı hazır değil.'));return a.edge(action,Object.assign({source:'seflik-entry-repair-v582',seflik:activeSeflik(),folderSeflik:activeSeflik()},terminalAuth(),data||{}))}
  function withTimeout(promise,ms,msg){var timer=0;return Promise.race([Promise.resolve(promise),new Promise(function(_,reject){timer=setTimeout(function(){reject(new Error(msg||'10 saniyede cevap gelmedi.'))},ms||10000)})]).finally(function(){if(timer)clearTimeout(timer)})}
  function toast(t,s,k){try{var f=window.mesahaFloatToastV315||window.mesahaFloatToastV314;if(typeof f==='function')return f(t,s||'',k||'success')}catch(e){}try{if(window.toast)return window.toast(t+(s?' — '+s:''))}catch(e){} }
  function setStatus(text,kind){var st=$('seflikFolderStatusV528');if(st){st.textContent=text;st.dataset.kind=kind||''}var meta=$('seflikFolderRemoteMetaV528');if(meta)meta.textContent=text}

  function ensureOverlay(){
    var ov=$('seflikTransferOverlayV534');
    if(ov) return ov;
    ov=document.createElement('div');
    ov.id='seflikTransferOverlayV534';
    ov.className='seflik-transfer-overlay-v534 hidden';
    ov.setAttribute('role','status');
    ov.setAttribute('aria-live','polite');
    ov.setAttribute('aria-busy','true');
    ov.innerHTML='<div class="seflik-transfer-card-v534"><span class="seflik-transfer-spinner-v534" aria-hidden="true"></span><h3 id="seflikTransferTitleV534">Şeflik klasörü getiriliyor…</h3><p id="seflikTransferTextV534">Lütfen bekleyin.</p><div class="seflik-transfer-progress-v534"><span id="seflikTransferBarV534"></span></div><small>İnternet zayıfsa en son mevcut bilgiler gösterilir.</small></div>';
    document.body.appendChild(ov);
    return ov;
  }
  function show(title,text,percent){var ov=ensureOverlay(),t=$('seflikTransferTitleV534'),p=$('seflikTransferTextV534'),bar=$('seflikTransferBarV534');if(t)t.textContent=title||'Şeflik klasörü getiriliyor…';if(p)p.textContent=text||'Lütfen bekleyin.';if(bar)bar.style.width=Math.max(4,Math.min(100,Number(percent)||4))+'%';ov.classList.remove('hidden');document.body.classList.add('seflik-transfer-busy-v534')}
  function update(title,text,percent){var ov=$('seflikTransferOverlayV534');if(!ov||ov.classList.contains('hidden')){show(title,text,percent);return}var t=$('seflikTransferTitleV534'),p=$('seflikTransferTextV534'),bar=$('seflikTransferBarV534');if(title&&t)t.textContent=title;if(text&&p)p.textContent=text;if(bar&&percent!=null)bar.style.width=Math.max(4,Math.min(100,Number(percent)||4))+'%'}
  function hide(delay){setTimeout(function(){var ov=$('seflikTransferOverlayV534');if(ov)ov.classList.add('hidden');document.body.classList.remove('seflik-transfer-busy-v534')},Math.max(0,Number(delay)||0))}

  function applyEnsured(out){
    out=out||{};var f=out.folder||{};if(!clean(f.seflik))return;
    setJson(ACTIVE_KEY,{seflik:clean(f.seflik),seflik_key:clean(f.seflik_key||out.seflik_key),role:clean(f.role||'owner'),creator:!!(f.is_creator||out.is_creator),created_by_user_id:clean(f.created_by_user_id),updatedAt:new Date().toISOString()});
    try{var p=panel();p.activeSeflik=clean(f.seflik);p.seflik=p.seflik||clean(f.seflik);setJson(PANEL_KEY,p)}catch(e){}
    try{window.dispatchEvent(new Event('mesaha:seflik-folder-active-changed'))}catch(e){}
  }

  function avatarHtml(){var av=avatar(),n=userName();if(av)return '<img src="'+esc(av)+'" alt="" onerror="this.style.display=\'none\'">';return '<span class="avatar-fallback">'+esc((n||'K').charAt(0).toLocaleUpperCase('tr-TR'))+'</span>'}
  function showLocalMemberFallback(msg){
    var box=$('seflikMemberListV566'),sf=activeSeflik();if(!box||!sf)return;
    if(box.querySelector&&box.querySelector('.seflik-v564-user')&&!/yükleniyor|henüz|yerel|bağlantı/i.test(box.textContent||''))return;
    var a=active(),creator=a.creator===true||clean(a.role)==='owner',role=creator?'Kurucu':'Bu cihazdaki kullanıcı';
    box.innerHTML='<div class="seflik-v566-member-title"><b>Ekli Ormancılar</b><small>'+esc(sf)+'</small></div>'+
      '<div class="seflik-v564-note">'+esc(msg||'Sunucu üyelikleri kontrol ediliyor. Bağlantı zayıfsa yerel kullanıcı bilgisi gösterilir.')+'</div>'+
      '<div class="seflik-v566-member-list"><div class="seflik-v564-user '+(creator?'role-owner':'role-member')+'">'+avatarHtml()+'<div><b>'+esc(userName())+'</b><small>'+esc(role+(userEmail()?' • '+userEmail():''))+'</small></div></div></div>';
  }

  function renderInitialLoading(){
    setStatus('Şeflik klasörü getiriliyor…','busy');
    var box=$('seflikFolderListV528');
    if(box&&!box.querySelector('.seflik-division-card'))box.innerHTML='<div class="seflik-folder-empty">Şeflik klasörü getiriliyor…<br><small>Şeflikler, üyeler, bölmeler ve senkron kayıtları kontrol ediliyor.</small></div>';
    showLocalMemberFallback('Üyeler yükleniyor…');
  }
  function renderAccessBlocked(){
    var msg=blockedMessage();
    setStatus(msg,'error');
    var box=$('seflikFolderListV528');
    if(box&&!box.querySelector('.seflik-division-card'))box.innerHTML='<div class="seflik-folder-empty">Şeflik Klasörü kapalı<br><small>'+esc(msg)+' En son mevcut bilgiler gösteriliyor.</small></div>';
    var members=$('seflikMemberListV566');if(members)members.innerHTML='<div class="seflik-v564-note">'+esc(msg)+'</div>';
    update('Şeflik Klasörü kapalı',msg,100);hide(700);
    if(Date.now()-lastWarnAt>6000){lastWarnAt=Date.now();toast('Şeflik Klasörü kapalı',msg,'warning')}
    return false;
  }

  async function ensureServerFolder(){
    var sf=activeSeflik();
    if(!sf)return null;
    var out=await edge('seflik_folder_ensure_active',{seflik:sf,folderSeflik:sf,seflikKey:activeKey()});
    if(out&&out.ok)applyEnsured(out);
    return out;
  }

  async function refresh(source){
    if(refreshPromise)return refreshPromise;
    var sf=activeSeflik();
    lastStartedAt=Date.now();
    if(!cloudAccess())return Promise.resolve(renderAccessBlocked());
    show('Şeflik klasörü getiriliyor…','Cihazdaki son bilgiler hazırlanıyor.',8);
    renderInitialLoading();
    refreshPromise=(async function(){
      if(!sf){setStatus('Önce şeflik oluşturun veya seçin.','error');update('Şeflik seçilmedi','Önce şeflik oluşturun veya seçin.',100);hide(900);return false}
      if(!navigator.onLine){
        try{if(window.MesahaSeflikFolderV529&&window.MesahaSeflikFolderV529.autoSync)await window.MesahaSeflikFolderV529.autoSync()}catch(e){}
        setStatus('Bağlantı başarısız. En son mevcut bilgiler gösteriliyor.','error');
        update('Bağlantı başarısız','İnternet yok. En son mevcut bilgiler gösteriliyor.',100);
        showLocalMemberFallback('Bağlantı yok. Sunucu üyelikleri güncellenemedi; yerel kullanıcı bilgisi gösteriliyor.');
        hide(1200);return false;
      }
      try{
        await withTimeout((async function(){
          update('Şeflik klasörü getiriliyor…','Şeflik yetkisi kontrol ediliyor.',18);
          await ensureServerFolder();
          update('Şeflik klasörü getiriliyor…','Şeflik listesi güncelleniyor.',36);
          if(window.MesahaSeflikGovernanceApi&&window.MesahaSeflikGovernanceApi.loadFolders)await window.MesahaSeflikGovernanceApi.loadFolders(true,true);
          update('Şeflik klasörü getiriliyor…','Üyeler getiriliyor.',56);
          showLocalMemberFallback('Üyeler getiriliyor…');
          if(window.MesahaSeflikGovernanceApi&&window.MesahaSeflikGovernanceApi.loadMembers)await window.MesahaSeflikGovernanceApi.loadMembers(true,true);
          update('Şeflik klasörü getiriliyor…','Bölmeler ve ortak kayıtlar senkronize ediliyor.',76);
          if(window.MesahaSeflikFolderV529&&window.MesahaSeflikFolderV529.autoSync)await window.MesahaSeflikFolderV529.autoSync();
        })(),10000,'Bağlantı başarısız. Sunucu 10 saniye içinde cevap vermedi.');
        update('Şeflik klasörü hazır','Şeflikler, üyeler, bölmeler ve senkron kayıtları güncellendi.',100);
        setStatus('Şeflik klasörü güncellendi.','success');
        hide(450);return true;
      }catch(e){
        var msg=String(e&&e.message?e.message:e);
        setStatus('Bağlantı başarısız. En son mevcut bilgiler gösteriliyor.','error');
        update('Bağlantı başarısız','Sunucu cevap vermedi. En son mevcut bilgiler gösteriliyor.',100);
        showLocalMemberFallback('Bağlantı başarısız. Sunucu üyelikleri güncellenemedi; yerel kullanıcı bilgisi gösteriliyor.');
        try{if(window.MesahaSeflikFolderV529&&window.MesahaSeflikFolderV529.autoSync)await window.MesahaSeflikFolderV529.autoSync()}catch(_e){}
        if(Date.now()-lastWarnAt>9000){lastWarnAt=Date.now();toast('Bağlantı başarısız','Şeflik bilgileri güncellenemedi. En son mevcut bilgiler gösteriliyor.','warning')}
        hide(1400);return false;
      }
    })().finally(function(){refreshPromise=null});
    return refreshPromise;
  }

  function onSeflikEntry(){setTimeout(function(){refresh('entry').catch(function(){})},20)}
  function wrapShowView(){
    if(typeof window.showView==='function'&&!window.showView.__seflikEntryRepairV582){
      var original=window.showView;
      var wrapped=function(view){var r=original.apply(this,arguments);try{if(clean(view)==='seflikFolder')onSeflikEntry()}catch(e){}return r};
      wrapped.__seflikEntryRepairV582=true;
      window.showView=wrapped;
    }
  }
  function boot(){wrapShowView();if($('seflikFolderView')&&$('seflikFolderView').classList.contains('active')&&Date.now()-lastStartedAt>2500)onSeflikEntry()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
  [200,800,1600,3000].forEach(function(ms){setTimeout(boot,ms)});
  document.addEventListener('click',function(ev){var n=ev.target&&ev.target.closest&&ev.target.closest('[data-nav="seflikFolder"]');if(n){if(!cloudAccess()){ev.preventDefault();ev.stopPropagation();ev.stopImmediatePropagation();renderAccessBlocked();return false}show('Şeflik klasörü getiriliyor…','Şeflikler, üyeler, bölmeler ve senkron kayıtları kontrol ediliyor.',7);renderInitialLoading();onSeflikEntry()}},true);
  window.addEventListener('online',function(){var v=$('seflikFolderView');if(v&&v.classList.contains('active'))setTimeout(function(){refresh('online').catch(function(){})},600)});
  window.MesahaSeflikEntryRepairV581={refresh:refresh,showLoading:show,updateLoading:update,hideLoading:hide,showLocalMemberFallback:showLocalMemberFallback};window.MesahaSeflikEntryRepairV582=window.MesahaSeflikEntryRepairV581;
})();
;
